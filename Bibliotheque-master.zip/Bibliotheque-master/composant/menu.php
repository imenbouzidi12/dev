<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<div class="col-lg-3">
    <form method="get" action="index.php" > 
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="submit"  placeholder="chercher">Go!</button>
      </span>
      
      <input name="chercher" type="text" class="form-control" />
      
    </div>
 </from>

    <div class="col-lg-12">
          <div id="menu1">
        <h3>Themes</h3>
            <ul>
              <li><a href="index.php?chercher=Bandesdessinees">Bandes dessinées</a></li>
              <li><a href="index.php?chercher=Sciencessociales">Sciences sociales</a></li>
              <li><a href="index.php?chercher=Sciencesappliquees">Sciences appliquées</a></li>
              <li><a href="index.php?chercher=Informatique">Informatique</a></li>
              <li><a href="index.php?chercher=Manga">Manga</a></li>
              <li><a href="index.php?chercher=Histoire">Histoire</a></li>
              <li><a href="index.php?chercher=Roman">Roman</a></li>
              <li><a href="index.php?chercher=economie">economie</a></li>
              <li><a href="index.php?chercher=Philosophie">Philosophie</a></li>
              <li><a href="index.php?chercher=L_art">L'art</a></li>
              
            </ul>
          </div>
          <div id="menu2">
        <h3>Auteurs</h3>
            <ul>
              <li><a href="index.php?chercher=Hugo">Victor Hugo</a></li>
              <li><a href="index.php?chercher=Coelho">Paolo Coelho</a></li>
              <li><a href="index.php?chercher=Kishimoto">Masashi Kishimoto </a></li>
              <li><a href="index.php?chercher=Zep">Zep</a></li>
              <li><a href="index.php?chercher=Eiichiro">Eiichiro Oda</a></li>
              <li><a href="index.php?chercher=Anouilh">Jean Anouilh</a></li>
              <li><a href="index.php?chercher=Platon">Platon</a></li>
              <li><a href="index.php?chercher=Moliere">Molière</a></li>
              <li><a href="index.php?chercher=Kubo">Tite Kubo</a></li>
            </ul>
          </div>
  </div>
  </div>