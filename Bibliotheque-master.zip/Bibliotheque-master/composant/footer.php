<div class="foo">
    <div class="col-lg-4">

      <div class="social">
        <ul>
          <li><a href="#" ><img src="IMG/fb.png"><span>Facebook</span></a></li>
          <li><a href="#" ><img src="IMG/go.png"><span>Google+</span></a></li>
          <li><a href="#" ><img src="IMG/tw.png"><span>Twitter</span></a></li>
          <li><a href="#" ><img src="IMG/yt.png"><span>Youtube</span></a></li>
        </ul>
      </div>

    </div>

    <div class="col-lg-4">
      <div class="propos">
        <h2 class="foo-headline">A propos</h2>
        <p>Ce site a ete concu dans le cadre des mini projects asigner aux etudiants par leur proffesseurs Mr. M. Reda.<br><a href="admin/index.php">Administration</a>
      </p>
        
      </div>
    </div>
    
    <div class="col-lg-4">

      <div class="team">        
        <ul>
          <h2 class="foo-headline">Ce site est creer par:</h2>

          <li><a herf="#">Youssef Faraby</a></li>
          <li><a herf="#">Manar Bouhaddioui</a></li>
          <li><a herf="#">Youssef Jabbari</a></li>
        </ul>
      </div>  

    </div>
    

</div>
<div class="rights" >
  © 2016 copyrights to <span class="italic">FBJ</span>
</div>


<script type="text/javascript" src="CSS/bootstrap/js/bootstrap.min.js">
</script>